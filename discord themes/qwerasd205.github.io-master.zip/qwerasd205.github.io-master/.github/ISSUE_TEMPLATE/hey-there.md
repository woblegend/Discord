---
name: Hey There
about: 'Don''t use BetterDocs mmmk? Go to the BD server (here: https://discord.gg/2HScm8j
  ) and use the #theme repo and #plugin repo channels.'

---

Don't use BetterDocs mmmk? Go to the BD server (here: https://discord.gg/2HScm8j ) and use the #theme repo and #plugin repo channels.
