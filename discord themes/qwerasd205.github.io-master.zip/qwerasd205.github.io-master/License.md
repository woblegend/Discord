# Copyright Notice

This notice applies to all files within this repository even where not stated within the files.<br>
<br>
Copyright © 2017, 2018, Qwerasd | All rights reserved | DO NOT DISTRIBUTE
