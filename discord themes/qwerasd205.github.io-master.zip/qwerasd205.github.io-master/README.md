# qwerasd205.github.io

Used for stuff and stuff

# Copyright Notice

This notice applies to all files within this repository even where not stated within the files.<br>
<br>
Copyright © 2017, 2018, 2019, Qwerasd | All rights reserved | DO NOT DISTRIBUTE
